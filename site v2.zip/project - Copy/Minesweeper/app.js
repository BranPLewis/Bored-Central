const URL = "http://localhost:8080/";

Vue.createApp({
  data() {
    return {};
  },
  methods: {},
  created: function () {},
}).mount("#app");
