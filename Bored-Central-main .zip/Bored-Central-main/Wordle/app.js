var correctWord = "";
var winner = false;
var totalGuesses = 6;
var wordLength = 5;
var guessedWord = [];
var validWords = [];
var answers = [];
var GAME_OVER = false;
var havePlayed = false;
var newday;




var correctWordSplit = correctWord.split("");
console.log(correctWordSplit);




// time ----------- //
var myArray = ["a", "b", "c", "d", "e"];

var dateTime = moment().format("YYYYMMDD");
var dateNumber = parseInt(dateTime, 10);
var newDateNumber = parseInt(dateTime, 10);
newday = newDateNumber;
console.log(dateTime);
console.log(dateNumber);
console.log(newDateNumber);

console.log(myArray[dateNumber % myArray.length]);
// ---------------- //

function pickRandomWord() {
    if (correctWord == ""){
        var randomIndex = Math.floor(answers.length * Math.random());
        correctWord = answers[randomIndex];
        saveState();
    }
    console.log(correctWord);
}


function getWordList() {
    fetch("https://raw.githubusercontent.com/chidiwilliams/wordle/main/src/data/words.json").then(function(response) {
        response.json().then(function (data) {
            answers = data;
            validWords = data;

            //resetGame();
            pickRandomWord();
            genTiles();
            setupInputs();
        })
    });
}



function checkWord(correctWord, guessInput) {
    var result = [0, 0, 0, 0, 0];
    var letters = correctWord.split("");

    guessInput = guessInput.toLowerCase();
    for(var i = 0; i < wordLength; i++) {
        if(guessInput[i] == letters[i]) {
            letters[i] = null;
            result[i] = 1;
        }
    }

    for (var i = 0; i < wordLength; i++) {
        var index = letters.indexOf(guessInput[i]);

        if (index >= 0 && result[i] == 0) {
            result[i] = 2
            letters[index] = null;
        }
    }

    console.log(result);
    return result;

    
}



function genTiles(){
    var allGuessesDiv = document.querySelector(".grid");

    allGuessesDiv.innerHTML = "";

    for(i = 0; i < totalGuesses; i++){
        var newGuess = document.createElement("div");
        newGuess.classList.add("guess");
        allGuessesDiv.appendChild(newGuess);

        for(j = 0; j < wordLength; j++){
            var newLetter = document.createElement("span");
            newLetter.classList.add("letter");
            
            if(i < guessedWord.length) {

                newLetter.innerHTML = guessedWord[i][j];
                
                var checkedOutput = checkWord(correctWord, guessedWord[i]);
                if (checkedOutput[j] == 1) {
                    newLetter.classList.add("match");
                } else if (checkedOutput[j] == 2){
                    newLetter.classList.add("contains");
                } else {
                    newLetter.classList.add("notContained");
                }
                  
            } 
            
            newGuess.appendChild(newLetter);
        }

        allGuessesDiv.appendChild(newGuess);
    }
    
    
}


function setupInputs() {
    var guessButton = document.querySelector(".guessButton");
    keys();
    guessButton.onclick = function (){ 
        makeGuess();
        
    }
}

function makeGuess() {
    var guessInput = document.querySelector(".user_input");
    var messageDiv = document.querySelector(".message");
    
    if (GAME_OVER == false) { 
        if (guessInput.length == 5) {
            console.log(guessedWord);
            console.log(guessInput);
            messageDiv.innerHTML = "Five letters please.";
        }
        else if (!validWords.includes(guessInput.value)) {
            messageDiv.innerHTML = "Not a real word.";
        }
        else {
            var lastGuess = guessInput.value;
            lastGuess = lastGuess.toUpperCase();
            correctWord = correctWord.toUpperCase();
            guessedWord.push(lastGuess);
            guessInput.value = "";

            console.log(correctWord);
            console.log(lastGuess);
            
            if (lastGuess == correctWord) {
                console.log("hello1");
                messageDiv.innerHTML = "You win!";

                GAME_OVER = true;
                havePlayed = true;
                saveState();

            }
            else {
                console.log("hello2");
                messageDiv.innerHTML = "";
            }

            correctWord = correctWord.toLowerCase();
            genTiles();
            

            saveState();

        }

        if(guessedWord.length >= totalGuesses && !GAME_OVER) {
            GAME_OVER = true;
            messageDiv.innerHTML = "You lose!";
            havePlayed = true;

            saveState();
            
        }
    }
    
    console.log(guessedWord);

    

}

function keys() {
    document.onkeydown = function(event){
        if (event.key == "Enter") {
            makeGuess();
        }
    }
}

function saveDay() {
    localStorage.setItem("newday", JSON.stringify(newDateNumber));
}
function saveState() {
    localStorage.setItem("correctWord", JSON.stringify(correctWord));
    localStorage.setItem("guesses", JSON.stringify(guessedWord));
    localStorage.setItem("gameOver", JSON.stringify(GAME_OVER));
    localStorage.setItem("havePlayed", JSON.stringify(havePlayed));
    localStorage.setItem("day", JSON.stringify(dateNumber));
}
function loadState() {
    
    saveDay();


    correctWord = JSON.parse(localStorage.getItem("correctWord"));
    guessedWord = JSON.parse(localStorage.getItem("guesses"));
    GAME_OVER = JSON.parse(localStorage.getItem("gameOver"));
    havePlayed = JSON.parse(localStorage.getItem("havePlayed"));
    dateNumber = JSON.parse(localStorage.getItem("day"));
    newDateNumber = JSON.parse(localStorage.getItem("newday"));

    if(typeof correctWord.localStorage == "undefined") {
        localStorage.setItem("correctWord", JSON.stringify(correctWord));
    }

    if(typeof guessedWord.localStorage == "undefined") {
        localStorage.setItem("guesses", JSON.stringify(guessedWord));
    }

    if(typeof GAME_OVER.localStorage == "undefined") {
        localStorage.setItem("gameOver", JSON.stringify(GAME_OVER));
    }

    if(typeof havePlayed.localStorage == "undefined") {
        havePlayed = false;
        localStorage.setItem("havePlayed", JSON.stringify(havePlayed));
    }

    if(typeof dateNumber.localStorage == "undefined") {
        dateTime = moment().format("YYYYMMDD");
        dateNumber = parseInt(dateTime, 10);
        
        localStorage.setItem("dateNumber", JSON.stringify(dateNumber));
    }

    
   
}

function resetGame() {
    guessedWord = [];
    GAME_OVER = false;
    correctWord = "";
    havePlayed = false;
    saveState();

    console.log(correctWord)
    console.log(GAME_OVER)
    console.log(correctWord)
    console.log(havePlayed)
    console.log(dateNumber)
}

function checkPlayState() {
    if (newDateNumber !== dateNumber) {
        resetGame();
        getWordList();
    } else if (newDateNumber == dateNumber && havePlayed == false && GAME_OVER == false) {
        loadState();
        getWordList();
        console.log("run2")

    } else {
        console.log("run3")
        var alreadyCompleted1 = document.querySelector(".completed1");
        alreadyCompleted1.innerHTML = "You have already completed todays Wordle.";

    }
    
    
}

window.onload = function() {
    if(typeof window.localStorage !== "undefined" && !localStorage.getItem('visited')) {
        localStorage.setItem('visited', true);
        resetGame();

        loadState();
        console.log(correctWord)
        console.log(GAME_OVER)
        console.log(correctWord)
        console.log(havePlayed)
        console.log(dateNumber)
        console.log(newDateNumber)

        console.log("Hello, This is your first time visiting.");
        
        getWordList();
        saveState();
        console.log("saved1")

    } else {
        
        // resetGame();

        loadState();
        checkPlayState();
        

    }
}

window.onclose = function() {
    saveState();
}
















